To run the project to play against the player, run the form.py file
to train the project from scratch, run the Ai_Training.py file
to create a testing set, run Ai_Training.py file
to test the random agent, run Testing_Control.py file
to interpret test results, run results.py file